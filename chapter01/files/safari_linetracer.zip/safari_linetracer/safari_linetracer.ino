// =========================================================
// Safari Linetracer - Firmware v0.1.0
// =========================================================
#define SAFARI_FIRMWARE_VERSION "0.1.0"

#include "debug_serial.h"
#include "ota_ap.h"
#include <Preferences.h>

uint32_t last_ota_duration = 0;
extern volatile bool is_ota_updating;

// ===== 모터 핀(원 코드 유지) =====
#define MOTOR1_PWM1 26
#define MOTOR1_PWM2 27
#define MOTOR2_PWM1 4
#define MOTOR2_PWM2 18

// ===== 3채널 IR 센서 핀 (L, C, R) =====
#define IR_L_PIN 33
#define IR_C_PIN 39
#define IR_R_PIN 36

// ===== 아날로그 임계값(중요!) =====
// 0~4095 범위(ESP32 기본 12bit)
// 센서가 검정(라인)에서 값이 "작아지는" 타입이 많아서 기본을 그렇게 둠.
// 시리얼로 raw 값 보고 조정해야 함.
int TH_L = 500;
int TH_C = 500;
int TH_R = 500;

// 검정(라인)에서 값이 더 작으면 true, 더 크면 false로 바꿔야 함.
const bool LINE_IS_DARK_LOW = false;

// ===== 모터 제어 (BOOST 삭제) =====
void setMotorSpeed(int motor1Speed, int motor2Speed) {
  motor1Speed = constrain(motor1Speed, -255, 255);
  motor2Speed = constrain(motor2Speed, -255, 255);

  // Motor1
  if (motor1Speed >= 0) {
    analogWrite(MOTOR1_PWM1, motor1Speed);
    analogWrite(MOTOR1_PWM2, 0);
  } else {
    analogWrite(MOTOR1_PWM1, 0);
    analogWrite(MOTOR1_PWM2, -motor1Speed);
  }

  // Motor2
  if (motor2Speed >= 0) {
    analogWrite(MOTOR2_PWM1, motor2Speed);
    analogWrite(MOTOR2_PWM2, 0);
  } else {
    analogWrite(MOTOR2_PWM1, 0);
    analogWrite(MOTOR2_PWM2, -motor2Speed);
  }
}

// 아날로그 값을 "라인 감지(true/false)"로 변환
bool isLine(int raw, int th) {
  if (LINE_IS_DARK_LOW) {
    return (raw < th);   // 검정에서 값이 내려가면 라인
  } else {
    return (raw > th);   // 검정에서 값이 올라가면 라인
  }
}

void setup() {
  setCpuFrequencyMhz(240); // CPU 클럭 최대 설정 (연산 및 flash 쓰기 가속)
  Serial.begin(115200);

  // Read and print last OTA duration if any (saved in NVS)
  Preferences prefs;
  prefs.begin("ota", false);
  last_ota_duration = prefs.getUInt("duration", 0);
  if (last_ota_duration > 0) {
    Serial.printf("[System] Last OTA Upload took: %.2f seconds\n", last_ota_duration / 1000.0);
    prefs.putUInt("duration", 0); // Reset
  }
  prefs.end();

  pinMode(MOTOR1_PWM1, OUTPUT);
  pinMode(MOTOR1_PWM2, OUTPUT);
  pinMode(MOTOR2_PWM1, OUTPUT);
  pinMode(MOTOR2_PWM2, OUTPUT);

  pinMode(IR_L_PIN, INPUT_PULLUP);
  pinMode(IR_C_PIN, INPUT_PULLUP);
  pinMode(IR_R_PIN, INPUT_PULLUP);

  // WiFi & OTA 설정 호출
  setupOTA();

  Serial.printf("3CH Analog Line Tracer Initialized (v%s).\n", SAFARI_FIRMWARE_VERSION);
  Serial.println("Tip: Check raw values and tune TH_L/TH_C/TH_R.");
}

void loop() {
  // OTA 진행 중에는 모터 주행/센서동작을 정지하고 OTA 핸들링에 집중 (Fast Loop)
  if (is_ota_updating) {
    ArduinoOTA.handle();
    yield(); // delay 없이 WiFi/TCP 태스크에 즉시 양보 (전송 안정성 향상)
    return;
  }

  // WiFi & OTA & WebServer & Telnet 핸들러 호출
  handleWiFi();

  // 센서 raw 읽기
  int rawL = analogRead(IR_L_PIN);
  int rawC = analogRead(IR_C_PIN);
  int rawR = analogRead(IR_R_PIN);

  // 라인 여부
  bool L = isLine(rawL, TH_L);
  bool C = isLine(rawC, TH_C);
  bool R = isLine(rawR, TH_R);

  // ===== 100ms 주기 시리얼 및 웹 대시보드 출력 =====
  static unsigned long lastPrintTime = 0;
  if (millis() - lastPrintTime >= 100) {
    Serial.printf("|RAW| %4d %4d %4d |LINE| %d%d%d | ", rawL, rawC, rawR, L, C, R);
    
    if (!L && C && !R) {                // 010  C   인식 => 직진 ↑
      Serial.println("직진");
    } else if (L && !C && !R) {         // 100 L    인식 => 라인이 왼쪽으로 많이 치우침   => 좌회전 더 ←
      Serial.println("좌회전 더");
    } else if (L && C && !R) {          // 110 LC   인식 => 라인이 왼쪽으로 치우침       => 좌회전 ↖
      Serial.println("좌회전");
    } else if (!L && C && R) {          // 011  CR  인식 => 라인이 오른쪽으로 치우침      => 우회전 ↗
      Serial.println("우회전");
    } else if (!L && !C && R) {         // 001   R  인식 => 라인이 오른쪽으로 많이 치우침  => 우회전 더 →
      Serial.println("우회전 더");
    } else if (L && C && R) {           // 111  종료 지점 => 정지 -
      Serial.println("정지");
    } else {                            // 000  라인 놓침 => 후진 ↓
      Serial.println("후진");
    }
    lastPrintTime = millis();
  }

  // ===== 5ms 주기 모터 제어 로직 =====
  if (!L && C && !R) {                  // 010  C   인식 => 직진 ↑
    setMotorSpeed(200, 200);
  } else if (L && !C && !R) {           // 100 L    인식 => 라인이 왼쪽으로 많이 치우침   => 좌회전 더 ←
    setMotorSpeed(40, 200);
  } else if (L && C && !R) {            // 110 LC   인식 => 라인이 왼쪽으로 치우침       => 좌회전 ↖
    setMotorSpeed(60, 200);
  } else if (!L && C && R) {            // 011  CR  인식 => 라인이 오른쪽으로 치우침      => 우회전 ↗
    setMotorSpeed(200, 60);
  } else if (!L && !C && R) {           // 001   R  인식 => 라인이 오른쪽으로 많이 치우침  => 우회전 더 →
    setMotorSpeed(200, 40);
  } else if (L && C && R) {             // 111  종료 지점 => 정지 -
    setMotorSpeed(0, 0);
  } else {                              // 000  라인 놓침 => 후진 ↓
    setMotorSpeed(-200, -200);
  }

  delay(5);
}

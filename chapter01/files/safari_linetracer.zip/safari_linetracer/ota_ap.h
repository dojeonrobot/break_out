// =========================================================
// Safari Linetracer - ota_ap.h v0.1.0
// =========================================================
#ifndef OTA_AP_H
#define OTA_AP_H

#include <WiFi.h>
#include <ESPmDNS.h>
#include <WiFiUdp.h>
#include <ArduinoOTA.h>
#include <Preferences.h>

#include "webserver.h"
#include "telnet.h"

// ===== WiFi 및 OTA 설정 (AP 모드) =====
// 외부 WiFi 공유기 없이, ESP32가 자체적으로 WiFi 핫스팟(AP)을 개설하여 무선 업로드(OTA)를 수행합니다.
// 노트북/스마트폰 등에서 이 WiFi에 직접 연결한 후 업로드 및 대시보드 조회가 가능합니다.
const char* ap_ssid = "Safari-Linetracer-00"; // WiFi 핫스팟 이름이자 기기 식별용 이름
const char* ap_password = "linetracer00";      // WiFi 비밀번호 (최소 8자 이상 or 암호를 지우려면 NULL 또는 "")

static unsigned long ota_start_time = 0;
volatile bool is_ota_updating = false;

void setupOTA() {
  hwSerial.println("Starting WiFi Access Point (AP)...");
  WiFi.mode(WIFI_AP);

  if (ap_password != NULL && strlen(ap_password) >= 8) {
    WiFi.softAP(ap_ssid, ap_password);
  } else {
    WiFi.softAP(ap_ssid);
  }

  WiFi.setSleep(false);                    // WiFi Sleep 비활성화 (속도 향상 핵심)
  WiFi.setTxPower(WIFI_POWER_19_5dBm);     // WiFi 송신 출력 최대화 (패킷 재전송 최소화)

  IPAddress myIP = WiFi.softAPIP();
  hwSerial.print("AP IP address (Upload/Dashboard IP): ");
  hwSerial.println(myIP); // 기본값은 보통 192.168.4.1 입니다.

  // OTA 기기 이름 설정 (mDNS 검색용)
  ArduinoOTA.setHostname(ap_ssid);

  // OTA 시작, 종료, 진행률, 에러에 대한 콜백 정의
  ArduinoOTA.onStart([]() {
    is_ota_updating = true;
    Serial.println("|OTA_STATE|START");
    // 안전을 위해 즉시 모터 정지
    analogWrite(26, 0);
    analogWrite(27, 0);
    analogWrite(4, 0);
    analogWrite(18, 0);
    // OTA 전송용 TCP 소켓 확보를 위해 기존 네트워크 연결 전체 해제
    for (int i = 0; i < 4; i++) {
      if (sseClients[i]) sseClients[i].stop();
    }
    if (telnetClient) telnetClient.stop();
    // 서버 리스닝 소켓도 중단하여 소켓 2개 추가 확보 + OTA 중 새 연결 유입 차단
    webServer.end();
    telnetServer.end();
    ota_start_time = millis();
    String type;
    if (ArduinoOTA.getCommand() == U_FLASH) {
      type = "sketch";
    } else { // U_SPIFFS
      type = "filesystem";
    }
    hwSerial.println("Start updating " + type);
  });
  
  ArduinoOTA.onEnd([]() {
    is_ota_updating = false;
    unsigned long elapsed = millis() - ota_start_time;
    hwSerial.println("\nEnd update");
    hwSerial.printf("Update Finished! Elapsed time: %.2f seconds\n", elapsed / 1000.0);
    
    // Save duration to NVS so we can read and print it on next boot
    Preferences prefs;
    prefs.begin("ota", false);
    prefs.putUInt("duration", elapsed);
    prefs.end();
  });
  
  ArduinoOTA.onProgress([](unsigned int progress, unsigned int total) {
    // OTA 전송 속도 극대화를 위해 시리얼 출력 완전 제거 (I/O 블로킹 0)
  });
  
  ArduinoOTA.onError([](ota_error_t error) {
    is_ota_updating = false;
    hwSerial.printf("Error[%u]: ", error);
    if (error == OTA_AUTH_ERROR) hwSerial.println("Auth Failed");
    else if (error == OTA_BEGIN_ERROR) hwSerial.println("Begin Failed");
    else if (error == OTA_CONNECT_ERROR) hwSerial.println("Connect Failed");
    else if (error == OTA_RECEIVE_ERROR) hwSerial.println("Receive Failed");
    else if (error == OTA_END_ERROR) hwSerial.println("End Failed");
  });

  ArduinoOTA.begin();
  hwSerial.println("OTA Ready");

  // Web 서버 및 Telnet 서버 시작
  setupWebServer();
  setupTelnet();
}

// WiFi, OTA, WebServer, Telnet 처리 공통 핸들러
void handleWiFi() {
  // 매 루프마다 끊어진 클라이언트 소켓 사전 회수 (OTA 소켓 확보)
  cleanupDeadClients();
  // AP 모드이거나 STA 모드에서 연결되었을 때 통신 핸들러 실행
  if (WiFi.getMode() == WIFI_AP || WiFi.status() == WL_CONNECTED) {
    ArduinoOTA.handle();
    handleWebServer();
    handleTelnet();
  }
}

#endif // OTA_AP_H

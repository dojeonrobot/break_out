// =========================================================
// Safari Linetracer - telnet.h v0.1.0
// =========================================================
#ifndef TELNET_H
#define TELNET_H

#include <WiFi.h>

WiFiServer telnetServer(23); // Telnet 기본 포트(23) 사용
WiFiClient telnetClient;     // Telnet 클라이언트 (debug_serial.h의 extern telnetClient 실제 정의)

void setupTelnet() {
  telnetServer.begin();
  telnetServer.setNoDelay(true);
}

void handleTelnet() {
  WiFiClient newClient = telnetServer.accept();
  if (!newClient) {
    newClient = telnetServer.available();
  }

  if (newClient) {
    if (telnetClient) {
      telnetClient.stop();
    }
    telnetClient = newClient;
    telnetClient.setTimeout(10); // 타임아웃을 10ms로 줄여 전송 실패 시 루프 뻗는 현상 방지
    telnetClient.println("--- Connected to Safari Linetracer Telnet Serial ---");
    Serial.println("New Telnet client connected!");
  }
}

#endif

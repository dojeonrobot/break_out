// =========================================================
// Safari Linetracer - webserver.h v0.1.0
// =========================================================
#ifndef WEBSERVER_H
#define WEBSERVER_H

#include <WiFi.h>
#include "dashboard.h"

WiFiServer webServer(80);     // HTTP 기본 포트 80 사용
WiFiClient sseClients[4];     // 실시간 웹 로그 스트리밍용 SSE 클라이언트 (최대 4명)

void setupWebServer() {
  webServer.begin();
}

// 끊어진 SSE/Telnet 클라이언트 소켓을 사전 회수하여 OTA용 소켓 풀 확보
void cleanupDeadClients() {
  for (int i = 0; i < 4; i++) {
    if (sseClients[i] && !sseClients[i].connected()) {
      sseClients[i].stop();
    }
  }
  if (telnetClient && !telnetClient.connected()) {
    telnetClient.stop();
  }
}

void handleWebServer() {
  WiFiClient client = webServer.accept();
  if (client) {
    String currentLine = "";
    boolean isGetEvents = false;
    boolean isGetRoot = false;
    
    // HTTP 요청 파싱 (헤더 끝까지 읽음, 모터 제어 루프 방해 방지를 위해 최대 15ms 타임아웃 적용)
    unsigned long parsingStart = millis();
    while (client.connected() && (millis() - parsingStart < 15)) {
      if (client.available()) {
        char c = client.read();
        if (c == '\n') {
          if (currentLine.length() == 0) {
            // 헤더 완료
            break;
          }
          if (currentLine.indexOf("GET /events") >= 0) {
            isGetEvents = true;
          } else if (currentLine.indexOf("GET / ") >= 0) {
            isGetRoot = true;
          }
          currentLine = "";
        } else if (c != '\r') {
          currentLine += c;
        }
      }
    }
    
    if (isGetEvents) {
      client.setTimeout(10); // 타임아웃을 10ms로 줄여 전송 실패 시 루프가 뻗는 현상을 방지
      // Event-Stream 헤더 전송
      client.println("HTTP/1.1 200 OK");
      client.println("Content-Type: text/event-stream");
      client.println("Cache-Control: no-cache");
      client.println("Connection: keep-alive");
      client.println("Access-Control-Allow-Origin: *");
      client.println();
      client.println("data: --- Connected to Web Serial Dashboard ---\n\n");
      extern uint32_t last_ota_duration;
      if (last_ota_duration > 0) {
        client.printf("data: |OTA_TIME| %.2f\n\n", last_ota_duration / 1000.0);
      }
      client.flush();

      // 빈 슬롯 또는 끊어진 클라이언트 자리에 할당
      bool added = false;
      for (int i = 0; i < 4; i++) {
        if (!sseClients[i] || !sseClients[i].connected()) {
          if (sseClients[i]) {
            sseClients[i].stop();
          }
          sseClients[i] = client;
          added = true;
          Serial.printf("New Web Dashboard client connected to slot %d!\n", i);
          break;
        }
      }

      if (!added) {
        // 자리가 다 찬 경우, 가장 오래된 접속자(0번)를 끊고 할당
        sseClients[0].stop();
        sseClients[0] = client;
        Serial.println("SSE slots full. Overwrote client slot 0.");
      }
    } 
    else if (isGetRoot) {
      // 대시보드 HTML 페이지 응답
      client.println("HTTP/1.1 200 OK");
      client.println("Content-Type: text/html; charset=utf-8");
      client.println("Connection: close");
      client.println();
      client.print(dashboard_html);
      client.flush();
      client.stop();
    }
    else {
      client.println("HTTP/1.1 404 Not Found");
      client.println("Connection: close");
      client.println();
      client.stop();
    }
  }
}

#endif

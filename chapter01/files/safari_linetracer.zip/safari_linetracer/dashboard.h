// =========================================================
// Safari Linetracer - dashboard.h v0.1.0
// =========================================================
#ifndef DASHBOARD_H
#define DASHBOARD_H

#include <Arduino.h>

const char dashboard_html[] PROGMEM = R"rawhtml(
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Safari Linetracer Dashboard v0.1.0</title>
  <style>
    body { background-color: #0e1117; color: #c9d1d9; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif; margin: 0; padding: 20px; display: flex; flex-direction: column; align-items: center; min-height: 100vh; box-sizing: border-box; }
    .container { width: 100%; max-width: 800px; display: flex; flex-direction: column; gap: 20px; }
    header { display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #21262d; padding-bottom: 10px; }
    h1 { margin: 0; font-size: 22px; color: #58a6ff; display: flex; align-items: center; gap: 10px; }
    .status-badge { background-color: #da3637; color: white; padding: 4px 10px; border-radius: 12px; font-size: 12px; font-weight: bold; transition: background-color 0.3s ease; }
    .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; }
    @media (max-width: 600px) { .grid { grid-template-columns: 1fr; } }
    .card { background-color: #161b22; border: 1px solid #30363d; border-radius: 8px; padding: 15px; display: flex; flex-direction: column; justify-content: space-between; }
    .card-title { font-size: 13px; color: #8b949e; margin-bottom: 15px; text-transform: uppercase; font-weight: bold; letter-spacing: 0.5px; }
    .action-val { font-size: 32px; color: #ff7b72; font-weight: bold; text-align: center; margin: auto 0; text-shadow: 0 0 10px rgba(255,123,114,0.2); }
    .sensor-values { display: flex; justify-content: space-around; }
    .sensor-box { display: flex; flex-direction: column; align-items: center; gap: 8px; }
    .sensor-label { font-size: 11px; color: #8b949e; font-weight: bold; }
    .sensor-num { color: #58a6ff; font-weight: bold; font-family: monospace; font-size: 15px; }
    .sensor-bar { width: 30px; height: 120px; background-color: #21262d; border-radius: 6px; overflow: hidden; display: flex; align-items: flex-end; border: 1px solid #30363d; }
    .sensor-fill { width: 100%; background-color: #58a6ff; transition: height 0.05s ease; box-shadow: 0 0 8px rgba(88,166,255,0.5); }
    .led-container { display: flex; gap: 15px; justify-content: center; margin-top: 10px; border-top: 1px solid #21262d; padding-top: 15px; }
    .led-box { display: flex; flex-direction: column; align-items: center; gap: 5px; }
    .led-label { font-size: 10px; color: #8b949e; }
    .led { width: 14px; height: 14px; border-radius: 50%; background-color: #21262d; border: 1px solid #30363d; transition: background-color 0.1s ease, box-shadow 0.1s ease; }
    .terminal { background-color: #010409; border: 1px solid #30363d; border-radius: 8px; height: 300px; font-family: "SFMono-Regular", Consolas, "Liberation Mono", Menlo, monospace; font-size: 12px; padding: 15px; overflow-y: auto; white-space: pre-wrap; line-height: 1.6; color: #7eea00; box-shadow: inset 0 0 15px rgba(0,0,0,0.8); }
    .terminal::-webkit-scrollbar { width: 8px; }
    .terminal::-webkit-scrollbar-track { background: #010409; }
    .terminal::-webkit-scrollbar-thumb { background: #21262d; border-radius: 4px; }
    .dropdown-item:hover { background-color: #21262d; }
    .ota-overlay {
      position: fixed;
      inset: 0;
      display: none;
      align-items: center;
      justify-content: center;
      background: rgba(14, 17, 23, 0.78);
      backdrop-filter: blur(4px);
      z-index: 1000;
    }
    .ota-panel {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 14px;
      padding: 24px 28px;
      border-radius: 14px;
      background: #161b22;
      border: 1px solid #30363d;
      box-shadow: 0 12px 40px rgba(0, 0, 0, 0.45);
      text-align: center;
    }
    .ota-spinner {
      width: 42px;
      height: 42px;
      border-radius: 50%;
      border: 4px solid #30363d;
      border-top-color: #58a6ff;
      animation: ota-spin 0.9s linear infinite;
    }
    .ota-title {
      color: #c9d1d9;
      font-size: 18px;
      font-weight: 700;
    }
    .ota-subtitle {
      color: #8b949e;
      font-size: 13px;
      line-height: 1.4;
      max-width: 280px;
    }
    .ota-progress {
      width: 240px;
      display: flex;
      flex-direction: column;
      gap: 8px;
      align-items: center;
    }
    .ota-progress-track {
      width: 100%;
      height: 8px;
      border-radius: 999px;
      overflow: hidden;
      background: #30363d;
    }
    .ota-progress-bar {
      width: 0%;
      height: 100%;
      border-radius: inherit;
      background: linear-gradient(90deg, #58a6ff, #7ee787);
      transition: width 0.15s linear;
    }
    .ota-progress-text {
      color: #c9d1d9;
      font-size: 12px;
      font-weight: 600;
      letter-spacing: 0.2px;
    }
    .ui-disabled {
      pointer-events: none;
      opacity: 0.45 !important;
      filter: grayscale(0.25);
    }
    @keyframes ota-spin {
      from { transform: rotate(0deg); }
      to { transform: rotate(360deg); }
    }
  </style>
</head>
<body>
  <div id="ota-overlay" class="ota-overlay" aria-hidden="true">
    <div class="ota-panel">
      <div class="ota-spinner"></div>
      <div class="ota-title">OTA Uploading...</div>
      <div class="ota-subtitle">대시보드와 제어 버튼이 잠시 비활성화됩니다.</div>
      <div class="ota-progress">
        <div class="ota-progress-track">
          <div id="ota-progress-bar" class="ota-progress-bar"></div>
        </div>
        <div id="ota-progress-text" class="ota-progress-text">0%</div>
      </div>
    </div>
  </div>
  <div class="container">
    <header>
      <h1>🏎️ Safari Linetracer Dashboard</h1>
      <div style="display: flex; align-items: center; gap: 8px;">
        <span id="ota-badge" style="display: none; background-color: #21262d; border: 1px solid #30363d; color: #8b949e; padding: 4px 10px; border-radius: 12px; font-size: 12px; font-weight: bold;"></span>
        <span class="status-badge" id="conn-status">CONNECTING</span>
      </div>
    </header>
    
    <div class="grid">
      <div class="card">
        <div class="card-title">Current Action</div>
        <div style="text-align: center; margin: 15px 0; display: flex; align-items: center; justify-content: center; height: 100px;">
          <img id="car-img" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAApIAAAJoCAYAAADVgQEZAAAQAElEQVR4nOzde5CddX3H8d9uNoRrAhEQSblJTFELioFaL3ijUluttqPtqH/otGrV6tTWUWeqVUHbcWxttVovtdVpHa+t4zhVqYNotV6rBLmI3MKdIAQIJBASyCbb85z1nJyzOcme89nbczavl7NkzyG7e4Z8ffJ+fs9znmesQGhs9dqJAsCiML5+3UiBAY0WAAAICEkAACJjBWZB45BIAWC4jK1eW2AmrEgCABARkgAARIQkAAARIQkAQERIAgAQEZIAAESEJAAAESEJAEBESAIAEHFnG4CGkYMO++XHoV3PtUxsu++Xv97fftx6jv3bvmZn6txUdm26rcBiISRZdAQB/armYnTlI9qfT/d7u3/f5Nft2vSLX/4qDvYnrdkZfG5K8+vMDYuFkGRREAQMot8I6Edr7lpxYH4Wt9GVx7b/zGf2fcwNi4OQZKgJAgYx3bxMnLys7DpnRdfj9tde92DXr6MXbN7j6zsDw/wsLvuanWpOJk4+sGteWp9PnZuR67a3P2+pvq/tDsNKSDKUBAGD2ttKUmtWOmekl9a/b/2665zlzRmqPjpnyOwsPktWrdljW9O5jdnX7Eydm1KWN/85esGWPbY9k9u0Q8vODdcUGBYjBUJjq9dOtD4fX7+uzJeZBkEvvYKgxSrBcNvbTkc1K1UMzpZeYVCdeysKhlc1M1VEdprJdqaXXnNTqeZmPs7dbmzH2583tuOagIEZGmLzHZKCgEHtLQR2vvboMld6zY+dkeHTa4d1trc1XT9vgeZGSDJTSwqEGhvac1uft96oMldaQTCytPscpJ1vO3bWVgY6v+/kIauR3YfBGz+3+oules47vIdDr4hshsCLV5a5NDmPI13nwVWvpXmVgPGHCvXXKyKrnY+JMw8pc6V1nuXoRVvbz03uNM/tNmdyuzapsR0/r8CAXJCc2ttbEMzlqtLkz1jedZ5lZbbe2MPc6jUz1bzM1WrSVNXPmTqfvc6zo346rwBRaa1gz/YOay/Vzxh/33FdP8s2h7qzjE1sPg5t7y0I5mOj3n4NjZWlJR/d2PXcfJ2/RGZqtFV/OQ9i6ciScvSyFeWYZUeUsdHRcv3WO8qdD20pibE33dL+3CkS9dd5qHdvp0Gcc9Tjy5898rn7+jZl58Sucuv2uxuzc3u5rvHx0803lJu23Vn6VW1zOle152ob69A2M+Vd29Ta1MNLgwbBbGitEnQGQfW6dm4QknVUHarrjMh+V64PXnJA+ZMTzinPO+bMctbDHl0OGF3a9e/v3bG1XHP/hrLu3uvK363/crnhgY19fd/q57d2RFo7RmKynnrttPZy/EFHlucec0YZxM6JneXTt3ynnHf1F/qanepoSOcOrLmhrhzaprYGDYJqleCrT3xb8+Nza99YDh87uMymzp/fa6WUhTf13LZ+3137jIc9tlz2zA+U95/6inL2UaftEZGVw5ceUn79iDXltSf9drn67A+Xjz3uNWXVgdOfbzn1UlStOy9RL+kOSL+WNFa5X378s5qz88fHnz3t75+6GmpuqCsrktRSEgRTVwnecdXnyr3jD5TZ0gqC1jsrWxt2h7jrY+rMTHdO5GFjB5b3PuZl5TUnPqeMjPR/VG/p6Fh59Ym/VV6y6qzyzO+/vVy8+fp9/v7W62jNjhXt+kl2QFo+fuMFZdND3X+eRy5bXo5rbJMec9hxzV9bqtn5yGmvLpdtubFc1Fjd3pep2xxzQx0JSWpp0CCYL4KgvjrffVqZbmaWNA7IXPjk85qrjJ3u27GtfPWOn5RLNt/Q+LixbNh+dznx4KPLmkOPLS8/7pnlcStOav/e5UsPLl9/0jvKU7/71nLN1n1fpqV6PZ07IdXrdUmgehh0dqZ63/ovl2u39r5yxWgZKc8/5sxy3ikvKaetOLH53LIlS8sXz3xLOfkbry07y659fu/JC99P3g3H3FBHDm1TOzPdqM+1ztfT2rCz8KbufEznTatfsEdEXrjx0nLq/7yhvHTd+8vfNuLggjsvKVfcd0v52h3ryvuv+0p5/LffWJ77w3eXG7be0f6ao5atKN948rnliKXTXxqm83XNxv2amR2Dzs4gdpWJ8uXbf1zO/sE7yvr7d8fmCY2dk8cu7++cb3NDnQlJamcuN+qzxYa9Xgbd+Tjl0FXl3FNe3H48MTFR/vTSfy7P/uG5076z9vyNF5enfe9tXVFw/MFHlVed8Owynep1dd2u0zlvC26+dlzvahz6ftMV/9b13BmHr+7rayevMWluqCchSa3UfTWyRRDUVz87H588/fXlwCUHtB//y03fKB+98eulX9VlXX7zB+8sD+7c0X7udSf9TvNw+SCvz05Ivcz1juuP7rm66/Fpy08o/TI31JWQpLbquhrZYsNeH92r2Pve+Th9xUnlSStPaT++bdum8pYr/r0Mqlq5/OTNF7YfV6uSz3/EmWUQdkAW3iCzM1MrxrpPf9gxsbMkzA114s021Mp8btRnkw37whn0HNXnPrz7+n9vvfLTZXP47v6/vuY/y5X33dp+fNMD019wunWYsn37Te/8XzCdszMfNzl4zsNP73rceXrEdMwNdSUkqY1he9OKDXv99LOKvfbwk7sef3/TlSV12/Z7yoduOL/MhLmph+o+13PpyUf8avNSU53+757BLjBevUbbG+rGoW1qqe6HtXuxKjkcjll2ePvz+8e3NW9fN9+6L1B+aGFxWjY6Vp6w4pHlE49/XfnWU97ddV7u1++4uFyy5cYyiO7zss0N9WBFEmag8zZmNuwLo/O/ez+HJ49atvuUiSu23FImCvurQWdnb87/jbeXh3aNdz135LLDytEdOy2dNj54b/mLn32ywGIgJKmN2dqow748uHP3X/grDxD/zNzqQ/t/s931jRXw5/3ob8pV928osBg4tA0Mtc5TCvrZAbn9wXvan598yDHlkCXzv9Pi0lH1MOjszNQ7rvxsOeWbry9X3n9rSZgb6siKJLUx3xv12WDDPnxu2XZX+/PRkdFy6vITyo8GfNNDp0ce/PDG95m8T3f1ru30ki4MryoQ73hwc9dzE43//e4xZzY/Wqo3epkPFhshCQy16p2rrYiv3tE63U7IN++8rLz8+Ge1H7/suGfEIXlGIwx+8vT3tR+/55ovlrde+Zlpv671ztuKd94unEFnZ28+v+F7Pe+1/aXbflSuPPtDzdtoVl7wiCeWl6w6q3xuw3dLwtxQRw5tUxudG8bODWad2bAPn//eeHEZ37V7Veg1Jz6nnLXy0SXx5tW/1/W4ilRouXvHfeXPL/9E13MfPPWV5agDhucauTAdIQnsV6p7Hr/32i+1H480Dkv/6+mvKweOLi2DeGljZelFxz65/bi6uPS37rq8r6/t3gG5v7B4fbax+lhd6qflyGXLyz+d9qqSMDfUkZCEGbBhX3id/91HL9jc19e86+r/KFdsubn9eM2hq8r3z3pP3/c+riLyU2vf0DzHsuXDN5zvUkJDpnN25vIoyGsu/VjZOr69/fgPVz21/H7jMDcsBkKS2kiCAJJTCh6aGC9/9NMPlZ0db3x4wuEnl4ue/r7y9jV/UI5YekjPr3vKylPKBU96Z/nMGW8sS0aWtJ//wobvlQ9e/7XSL/NdD92n02wvc6W6L/tfTTl39iOnvXqvc7Y3c/kaIeXNNtTG5Ea9/+ux1YEgWHhTz63t900TP7l3fXnLFZ9q3rZubHQyCpeOjpV3PfqlzY+bHthYfrr5hnLb9k3NywStOeTYctIhD9/j+1y48dLysnX/WHaF65G7Nt1WWBjp7CQ+dP355aW/8rRy5hGPaj4+5sAjygd+7RXl5T/9YN/fo3PV1NxQF0KS2pjtjfq6p/992dn4671f5131+fKB679aUjbsC6fz3beD+Ifr/qt8+66flU+e/vryuBUndf27Ew4+uvmxN7smdpVP3/Kd8vrLP95c4ezX6AVbdn+PTb8oLKx0dlqqOXhw145pf1+1LXrlJR9ubpdaOy4vO/6Z5RM3X1j+9+6fT/v15oa6EpLUykw36p0OW3rQQL9/2YBvtrBhr4/qv/+SVZNzU60S73zt0X1/7cWbry9nfufN5S/XvLC8bc2LygF9zMFXb/9JeevPP10uv+/mMiir2PWSzM6Fd15aXvjj9zY/v337PeXmjmuT7stlW24qz/r+29uXA6pc3niuH+aGuhKS1MpMgmC+2bDXx9TV7Cryd53T/yVWqotEV2/A+cB1XynnHP348qwjTy3HHXRkOeqAFWXz+NayZce25t1Irrrv1nLJlhvKz+/L7kzSufNRsYq98JIjITduu7P5kfjupivLoMwNdSYkqZWZBEHnKkHiZ1v6X12yYa+faidkdOXkObZV5A8Ski1bxreVL972w+bHXOjc+bCKXR9TZ6duO7DmhjoTktROGgQzWSUYlA17/VQxP3LQoe1TIwZdlZxrdj7qq3N2khXtuWRuqDuX/6F2qg1l58rk1A3pQrNhr6/OqK9ivy6zU70OOx/1NnV26nB3rcmoNTfUm5CklgQBiWoHpHsnZOGDoFcM2Pmon6mzs+SjGxd8dqrX0FK9NnNDHQlJakkQkNq54Zo9gmAhiYHhUc1Op4V8Q93UuZ362qAuhCS1JQhITV0pHnvTLfO+I1L9vOrnln28LuqnM9iqP8P53u60fmbnvIpI6kxIUmuCgEQV+lP/8q3+cp6vUySqn9NrRSm5nSPza3Incff/v1v//5+P7U6viKxei7mhzpYUCI2uPPbc1udzFlbjDzXvwT26/GG7f+5FWxv/HJmzW5l1agbBFzZ1PScIhkRjdqo56bzA/eRf0HM7O81gbc7obmZmuEz+WXXPzlxvd3pta+bj9JnGdrzz551XYEAjBUJjq9e2by48vn5dmUvVxq51SaCWXeesmNNLdPQ62V4QDKclq9bsccek2Z6fqW/EqrRWt8zMcKpmppqdqWZzdlrnXi/UtqaxHW9/3tiOawIGZmiIzWdItggCUr12RirV/FSrTMlK094ioPl9vRlr0ei13amk257WvPSanV6nZcwlIclMGRpiCxGSFUFAqnUYr9f8VKoZqrRmqHOWOmdjX1cRsNOxOO1tu1OZ3O4c2P6889fOOZm8BeP2nrOzUHMjJJkpd7Zh6HRGXeeGvevSPIKAHvY2O+3nZnC5F/OyuFWzU330CsrWPbrz721nleElJBlKgoCZ6IyCyt5WmqbTmhHzsv+YzdkxNywGQpKhJgiYidYOyeS9lg9rnwdX3Xd58tfd58V1zkV1JYGpF81n/9I5O53vfJ46O+aGxU5IsigIAmbKHJByWJr9mZBk0REEADA/3NkGAICIkAQAICIkAQCICEkAACJCEgCAiJAEACAiJAEAiAhJAAAiQhIAgMhIYWiNrV47UQBgERhfv06TDCErkgAARIQkAACRscKisOPaiwoADJOljzqjMNysSAIAEBGSAABEhCQAABEhCQBAREgCABARkgAARIQkAAARIQkAwfIgmwAACkpJREFUQERIAgAQEZIAAESEJAAAESEJAEBESAIAEBGSAABEhCQAABEhCQBAREgCABARkgAARIQkAAARIQkAQERIAgAQEZIAAESEJAAAESEJAEBESAIAEBGSAABEhCQAABEhCQBAREgCABARkgAARIQkAAARIQkAQERIAgAQEZIAAESEJAAAESEJAEBESAIAEBGSAABEhCQAABEhCQBAREgCABARkgAARIQkAAARIQkAQERIAgAQEZIAAESEJAAAESEJAEBESAIAEBGSAABEhCQAABEhCQBAREgCABARkgAARIQkAAARIQkAQERIAgAQEZIAAESEJAAAESEJAEBESAIAEBGSAABEhCQAABEhCQBAREgCABARkgAARIQkAAARIQkAQERIAgAQEZIAAESEJAAAESEJAEBESAIAEBGSAABEhCQAABEhCQBAREgCABARkgAARIQkAAARIQkAQERIAgAQEZIAAESEJAAAESEJAEBESAIAEBGSAABEhCQAABEhCQBAREgCABARkgAARIQkAAARIQkAQERIAgAQEZIAAESEJAAAESEJAEBESAIAEBGSAABEhCQAABEhCQBAREgCABARkgAARIQkAAARIQkAQERIAgAQEZIAAESEJAAAESEJAEBESAIAEBGSAABEhCQAABEhCQBAREgCABARkgAARIQkAAARIQkAQERIAgAQEZIAAESEJAAAESEJAEBESAIAEBGSAABEhCQAABEhCQBAREgCABARkgAARIQkAAARIQkAQERIAgAQEZIAAESEJAAAESEJAEBESAIAEBGSAABEhCQAABEhCQBAREgCABARkgAARIQkAAARIQkAQERIAgAQEZIAAESEJAAAESEJAEBESAIAEBGSAABEhCQAABEhCQBAREgCABARkgAARIQkAAARIQkAQERIAgAQEZIAAESEJAAAESEJAEBESAIAEBGSAABEhCQAABEhCQBAREgCABARkgAARIQkAAARIQkAQERIAgAQEZIAAESEJAAAESEJAEBESAIAEBGSAABEhCQAABEhCQBAREgCABARkgAARIQkAAARIQkAQERIAgAQEZIAAESEJAAAESEJAEBESAIAEBGSAABEhCQAABEhCQBAREgCABARkgAARIQkAAARIQkAQGSsQGjpo84oACwOO669qMCgrEgCABARkgAARBzaZlaMr19XABguY6vXFpgJK5IAAESEJAAAESEJAEBESAIAEBGSAABEhCQAABEhCQBAREgCABARkgAARIQkAAARIQkAQERIAgAQEZIAAESEJAAAESEJAEBESAIAEBGSAABEhCQAABEhCQBAREgCABARkgAARIQkAAARIQkAQERIAgAQEZIAAESEJAAAESEJAEBESAIAEBGSAABEhCQAABEhCQBAREgCABARkgAARMaa/1i9dqIAACwQLTKcrEgCABARkgAARMamPjG+fl1hODQOAxQAWAz0x/Do7A8rkgAARIQkAAARIQkAQERIAgAQEZIAAESEJAAAESEJAEBESAIAEBGSAABEhCQAABEhCQBAREgCABARkgAARIQkAAARIQkAQERIAgAQEZIAAESEJAAAESEJAEBESAIAEBGSAABEhCQAABEhCQBAREgCABARkgAARIQkAAARIQkAQERIAgAQEZIAAESEJAAAESEJAEBESAIAEBGSAABEhCQAABEhCQBAREgCABARkgAARIQkAAARIQkAQERIAgAQEZIAAESEJAAAESEJAEBESAIAEBGSAABEhCQAABEhCQBAREgCABARkgAARIQkAAARIQkAQERIAgAQEZIAAESEJAAAESEJAEBESAIAEBGSAABEhCQAABEhCQBAREgCABARkgAARIQkAAARIQkAQERIAgAQEZIAAESEJAAAESEJAEBESAIAEBGSAABEhCQAABEhCQBAREgCABARkgAARIQkAAARIQkAQERIAgAQEZIAAESEJAAAESEJAEBESAIAEBGSAABEhCQAABEhCQBAREgCABARkgAARIQkAAARIQkAQERIAgAQEZIAAESEJAAAESEJAEBESAIAEBGSAABEhCQAABEhCQBAREgCABARkgAARIQkAAARIQkAQERIAgAQEZIAAESEJAAAESEJAEBESAIAEBGSAABEhCQAABEhCQBAREgCABARkgAARIQkAAARIQkAQERIAgAQEZIAAESEJAAAESEJAEBESAIAEBGSAABEhCQAABEhCQBAREgCABARkgAARIQkAAARIQkAQERIAgAQEZIAAESEJAAAESEJAEBESAIAEBGSAABEhCQAABEhCQBAREgCABARkgAARIQkAAARIQkAQERIAgAQEZIAAESEJAAAESEJAEBESAIAEBGSAABEhCQAABEhCQBAREgCABARkgAARIQkAAARIQkAQERIAgAQEZIAAESEJAAAESEJAEBESAIAEBGSAABEhCQAABEhCQBAREgCABARkgAARIQkAAARIQkAQERIAgAQEZIAAESEJAAAESEJAEBESAIAEBGSAABEhCQAABEhCQBAREgCABARkgAARIQkAAARIQkAQERIAgAQEZIAAESEJAAAESEJAEBESAIAEBGSAABEhCQAABEhCQBAREgCABARkgAARIQkAAARIQkAQERIAgAQEZIAAESEJAAAESEJAEBESAIAEBGSAABEhCQAABEhCQBAREgCABARkgAARIQkAAARIQkAQERIAgAQEZIAAESEJAAAESEJAEBESAIAEBGSAABEhCQAABEhCQBAREgCABARkgAARIQkAAARIQkAQERIAgAQEZIAAESEJAAAESEJAEBESAIAEBGSAABEhCQAABEhCQBAREgCABARkgAARIQkAAARIQkAQERIAgAQEZIAAESEJAAAESEJAEBESAIAEBGSAABEhCQAABEhCQBAREgCABARkgAARIQkAAARIQkAQERIAgAQEZIAAESEJAAAESEJAEBESAIAEBGSAABEhCQAABEhCQBAREgCABARkgAARIQkAAARIQkAQERIAgAQEZIAAESEJAAAkbE9nli9tgAAzCf9MZysSAIAEBGSAABEmoe2x9evGykMncZhgIkCAIuAFhlOViQBAIgISQAAIkISAICIkAQAICIkAQCICEkAACJCEgCAiJAEACAiJAEAiAhJAAAiQhIAgIiQBAAgIiQBAIgISQAAIkISAICIkAQAICIkAQCICEkAACJCEgCAiJAEACAiJAEAiAhJAAAiQhIAgIiQBAAgIiQBAIgISQAAIkISAICIkAQAICIkAQCICEkAACJCEgCAiJAEACAiJAEAiAhJAAAiYwVmwdjqtQUA2L9YkQQAICIkAQCIOLRNbMe1FxUAYP9lRRIAgIiQBAAgIiQBAIgISQAAIkISAICIkAQAICIkAQCICEkAACJCEgCAiJAEACAiJAEAiAhJAAAiQhIAgIiQBAAgIiQBAIgISQAAIkISAICIkAQAICIkAQCIjBUWhaWPOqMAAMwnK5IAAESEJAAAkZECAACB/wcAAP//7ynpxAAAAAZJREFUAwCSrLwi7FlGFQAAAABJRU5ErkJggg==" style="max-width: 100%; max-height: 100%; object-fit: contain; transition: transform 0.3s ease, opacity 0.3s ease; opacity: 0.5;" />
        </div>
        <div class="action-val" id="action-text">WAITING</div>
      </div>
      <div class="card">
        <div class="card-title">Sensors & Lines</div>
        <div class="sensor-values">
          <div class="sensor-box">
            <span class="sensor-label">LEFT</span>
            <div class="sensor-bar"><div class="sensor-fill" id="bar-L" style="height: 0%"></div></div>
            <span class="sensor-num" id="val-L">0</span>
          </div>
          <div class="sensor-box">
            <span class="sensor-label">CENTER</span>
            <div class="sensor-bar"><div class="sensor-fill" id="bar-C" style="height: 0%"></div></div>
            <span class="sensor-num" id="val-C">0</span>
          </div>
          <div class="sensor-box">
            <span class="sensor-label">RIGHT</span>
            <div class="sensor-bar"><div class="sensor-fill" id="bar-R" style="height: 0%"></div></div>
            <span class="sensor-num" id="val-R">0</span>
          </div>
        </div>
        
        <div class="led-container">
          <div class="led-box">
            <span class="led-label">L</span>
            <div class="led" id="led-L"></div>
          </div>
          <div class="led-box">
            <span class="led-label">C</span>
            <div class="led" id="led-C"></div>
          </div>
          <div class="led-box">
            <span class="led-label">R</span>
            <div class="led" id="led-R"></div>
          </div>
        </div>
      </div>
    </div>

    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; margin-top: 15px; flex-wrap: wrap; gap: 10px;">
      <div style="display: flex; align-items: center; gap: 8px;">
        <span style="font-size: 13px; color: #8b949e; font-weight: bold; text-transform: uppercase; letter-spacing: 0.5px;">Terminal Logs</span>
        <div id="filter-presets" style="display: flex; gap: 4px; align-items: center;">
          <button class="btn-preset active" data-filter="" title="전체 로그 보기" style="background: #30363d; border: 1px solid #58a6ff; opacity: 1.0; padding: 0; border-radius: 6px; cursor: pointer; color: #c9d1d9; width: 26px; height: 26px; display: flex; align-items: center; justify-content: center; font-size: 11px; font-weight: bold; transition: all 0.2s ease;">A</button>
          <button class="btn-preset" data-filter="좌회전 더" title="좌회전 더 로그 필터" style="background: #21262d; border: 1px solid #30363d; opacity: 0.4; padding: 0; border-radius: 6px; cursor: pointer; color: #c9d1d9; width: 26px; height: 26px; display: flex; align-items: center; justify-content: center; transition: all 0.2s ease;">
            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="transform: rotate(-70deg);"><line x1="12" y1="19" x2="12" y2="5"></line><polyline points="5 12 12 5 19 12"></polyline></svg>
          </button>
          <button class="btn-preset" data-filter="좌회전" title="좌회전 로그 필터" style="background: #21262d; border: 1px solid #30363d; opacity: 0.4; padding: 0; border-radius: 6px; cursor: pointer; color: #c9d1d9; width: 26px; height: 26px; display: flex; align-items: center; justify-content: center; transition: all 0.2s ease;">
            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="transform: rotate(-35deg);"><line x1="12" y1="19" x2="12" y2="5"></line><polyline points="5 12 12 5 19 12"></polyline></svg>
          </button>
          <button class="btn-preset" data-filter="직진" title="직진 로그 필터" style="background: #21262d; border: 1px solid #30363d; opacity: 0.4; padding: 0; border-radius: 6px; cursor: pointer; color: #c9d1d9; width: 26px; height: 26px; display: flex; align-items: center; justify-content: center; transition: all 0.2s ease;">
            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="19" x2="12" y2="5"></line><polyline points="5 12 12 5 19 12"></polyline></svg>
          </button>
          <button class="btn-preset" data-filter="우회전" title="우회전 로그 필터" style="background: #21262d; border: 1px solid #30363d; opacity: 0.4; padding: 0; border-radius: 6px; cursor: pointer; color: #c9d1d9; width: 26px; height: 26px; display: flex; align-items: center; justify-content: center; transition: all 0.2s ease;">
            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="transform: rotate(35deg);"><line x1="12" y1="19" x2="12" y2="5"></line><polyline points="5 12 12 5 19 12"></polyline></svg>
          </button>
          <button class="btn-preset" data-filter="우회전 더" title="우회전 더 로그 필터" style="background: #21262d; border: 1px solid #30363d; opacity: 0.4; padding: 0; border-radius: 6px; cursor: pointer; color: #c9d1d9; width: 26px; height: 26px; display: flex; align-items: center; justify-content: center; transition: all 0.2s ease;">
            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="transform: rotate(70deg);"><line x1="12" y1="19" x2="12" y2="5"></line><polyline points="5 12 12 5 19 12"></polyline></svg>
          </button>
          <button class="btn-preset" data-filter="정지" title="정지 로그 필터" style="background: #21262d; border: 1px solid #30363d; opacity: 0.4; padding: 0; border-radius: 6px; cursor: pointer; color: #c9d1d9; width: 26px; height: 26px; display: flex; align-items: center; justify-content: center; transition: all 0.2s ease;">
            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line></svg>
          </button>
          <button class="btn-preset" data-filter="후진" title="후진 로그 필터" style="background: #21262d; border: 1px solid #30363d; opacity: 0.4; padding: 0; border-radius: 6px; cursor: pointer; color: #c9d1d9; width: 26px; height: 26px; display: flex; align-items: center; justify-content: center; transition: all 0.2s ease;">
            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="transform: rotate(180deg);"><line x1="12" y1="19" x2="12" y2="5"></line><polyline points="5 12 12 5 19 12"></polyline></svg>
          </button>
          <button id="btn-filtermode" title="필터링된 로그만 보기 / 흐리게 보기 전환" style="background: #21262d; border: 1px solid #30363d; opacity: 0.4; padding: 0; border-radius: 6px; cursor: pointer; color: #c9d1d9; width: 26px; height: 26px; display: flex; align-items: center; justify-content: center; transition: all 0.2s ease;">
            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"></polygon></svg>
          </button>
        </div>
        </div>
      <div style="display: flex; gap: 8px; align-items: center;">
        <button id="btn-autoscroll" title="자동 스크롤 켜기/끄기" style="background: #21262d; border: 1px solid #30363d; padding: 0; border-radius: 6px; cursor: pointer; color: #c9d1d9; width: 32px; height: 32px; display: flex; align-items: center; justify-content: center; transition: all 0.2s ease;">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"></line><polyline points="19 12 12 19 5 12"></polyline></svg>
        </button>
        <button id="btn-timestamp" title="타임스탬프 켜기/끄기" style="background: #21262d; border: 1px solid #30363d; padding: 0; border-radius: 6px; cursor: pointer; color: #c9d1d9; width: 32px; height: 32px; display: flex; align-items: center; justify-content: center; transition: all 0.2s ease;">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
        </button>
        <button id="btn-clear" title="로그 지우기" style="background: #21262d; border: 1px solid #30363d; padding: 0; border-radius: 6px; cursor: pointer; color: #c9d1d9; width: 32px; height: 32px; display: flex; align-items: center; justify-content: center; transition: all 0.2s ease;" onmouseover="this.style.backgroundColor='#30363d'" onmouseout="this.style.backgroundColor='#21262d'">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg>
        </button>
      </div>
    </div>
    <div class="terminal" id="term-log">Initializing terminal connection...</div>
  </div>

  <footer style="text-align: center; margin-top: auto; padding-top: 10px; padding-bottom: 10px; font-size: 12px; color: #484f58; border-top: 1px solid #21262d; width: 100%; max-width: 800px;">
    &copy; 2026 XYLO 박재민 | Powered by DORO Inc.
  </footer>

  <script>
    const term = document.getElementById("term-log");
    const valL = document.getElementById("val-L");
    const valC = document.getElementById("val-C");
    const valR = document.getElementById("val-R");
    const barL = document.getElementById("bar-L");
    const barC = document.getElementById("bar-C");
    const barR = document.getElementById("bar-R");
    const ledL = document.getElementById("led-L");
    const ledC = document.getElementById("led-C");
    const ledR = document.getElementById("led-R");
    const actText = document.getElementById("action-text");
    const status = document.getElementById("conn-status");
    const otaOverlay = document.getElementById("ota-overlay");
    const otaProgressBar = document.getElementById("ota-progress-bar");
    const otaProgressText = document.getElementById("ota-progress-text");

    let source = null;
    let reconnectTimer = null;
    let reconnectDelay = 1000;
    let otaProgressTimer = null;
    let otaProgressStart = 0;

    // Terminal Log State & Utilities
    let allLogs = []; // Contains raw timestamped lines
    let autoScroll = true;
    let showTimestamp = false; // Turned off by default
    let onlyShowFiltered = false; // Default: Dim mode (false)
    let activeFilter = ""; // Default: No filter (show all)
    let otaState = "idle";

    const btnFilterMode = document.getElementById("btn-filtermode");
    const btnAutoScroll = document.getElementById("btn-autoscroll");
    const btnTimestamp = document.getElementById("btn-timestamp");
    const btnClear = document.getElementById("btn-clear");
    const controlButtons = [
      ...document.querySelectorAll(".btn-preset"),
      btnFilterMode,
      btnAutoScroll,
      btnTimestamp,
      btnClear
    ].filter(Boolean);

    function setOtaUi(active) {
      if (otaOverlay) {
        otaOverlay.style.display = active ? "flex" : "none";
        otaOverlay.setAttribute("aria-hidden", active ? "false" : "true");
      }
      controlButtons.forEach(btn => {
        btn.disabled = active;
        btn.classList.toggle("ui-disabled", active);
      });
    }

    function setOtaProgress(percent) {
      const clamped = Math.max(0, Math.min(100, percent));
      if (otaProgressBar) {
        otaProgressBar.style.width = `${clamped}%`;
      }
      if (otaProgressText) {
        otaProgressText.textContent = `${clamped}%`;
      }
    }

    function stopOtaProgress() {
      if (otaProgressTimer) {
        clearInterval(otaProgressTimer);
        otaProgressTimer = null;
      }
    }

    function startOtaProgress() {
      stopOtaProgress();
      otaProgressStart = performance.now();
      setOtaProgress(0);
      otaProgressTimer = setInterval(() => {
        const elapsed = performance.now() - otaProgressStart;
        const estimated = Math.floor((1 - Math.exp(-elapsed / 8000)) * 92);
        setOtaProgress(estimated);
      }, 120);
    }

    function scheduleReconnect() {
      if (reconnectTimer) {
        return;
      }
      reconnectTimer = setTimeout(() => {
        reconnectTimer = null;
        connectEventSource();
      }, reconnectDelay);
      reconnectDelay = Math.min(reconnectDelay * 2, 10000);
    }

    function connectEventSource() {
      if (source) {
        source.close();
      }

      source = new EventSource("/events");

      source.onopen = () => {
        stopOtaProgress();
        reconnectDelay = 1000;
        otaState = "connected";
        status.textContent = "CONNECTED";
        status.style.backgroundColor = "#238636";
        setOtaUi(false);
        const otaBadge = document.getElementById("ota-badge");
        if (otaBadge) {
          otaBadge.style.display = "none";
        }
        allLogs = [getTimestamp() + " --- Web Terminal Connected ---"];
        renderLogs();
      };

      source.onerror = () => {
        if (otaState === "uploading") {
          status.textContent = "OTA UPLOADING";
          status.style.backgroundColor = "#d29922";
          setOtaUi(true);
        } else {
          status.textContent = "DISCONNECTED";
          status.style.backgroundColor = "#da3637";
          setOtaUi(false);
        }
        scheduleReconnect();
      };

      source.onmessage = (e) => {
        if (e.data === "|OTA_STATE|START") {
          otaState = "uploading";
          status.textContent = "OTA UPLOADING";
          status.style.backgroundColor = "#d29922";
          setOtaUi(true);
          startOtaProgress();

          const otaBadge = document.getElementById("ota-badge");
          if (otaBadge) {
            otaBadge.textContent = "OTA UPLOADING...";
            otaBadge.style.display = "inline-block";
            otaBadge.style.backgroundColor = "#d29922";
            otaBadge.style.borderColor = "#d29922";
            otaBadge.style.color = "#0e1117";
          }
          return;
        }

        if (e.data.startsWith("|OTA_TIME|")) {
          const duration = e.data.substring(10).trim();
          const otaBadge = document.getElementById("ota-badge");
          if (otaBadge && parseFloat(duration) > 0) {
            otaBadge.textContent = `Last OTA: ${duration}s`;
            otaBadge.style.display = "inline-block";
            otaBadge.style.backgroundColor = "#21262d";
            otaBadge.style.borderColor = "#30363d";
            otaBadge.style.color = "#8b949e";
          }
          return;
        }

        const rawLine = getTimestamp() + " " + e.data;
        allLogs.push(rawLine);
        appendSingleLog(rawLine);

        // 1. RAW 값 파싱 (정규식 이용)
        const rawMatch = e.data.match(/\|RAW\|\s*(\d+)\s+(\d+)\s+(\d+)/);
        if (rawMatch) {
          const l = parseInt(rawMatch[1]);
          const c = parseInt(rawMatch[2]);
          const r = parseInt(rawMatch[3]);

          valL.textContent = l;
          valC.textContent = c;
          valR.textContent = r;

          barL.style.height = Math.min(100, Math.max(0, (l / 40.95))) + "%";
          barC.style.height = Math.min(100, Math.max(0, (c / 40.95))) + "%";
          barR.style.height = Math.min(100, Math.max(0, (r / 40.95))) + "%";
        }

        // 2. LINE 값 파싱 (정규식 이용)
        const lineMatch = e.data.match(/\|LINE\|\s*([0-1])([0-1])([0-1])/);
        if (lineMatch) {
          const isL = lineMatch[1] === "0";
          const isC = lineMatch[2] === "0";
          const isR = lineMatch[3] === "0";

          ledL.style.backgroundColor = isL ? "#ff4444" : "#21262d";
          ledL.style.boxShadow = isL ? "0 0 8px #ff4444" : "none";

          ledC.style.backgroundColor = isC ? "#ff4444" : "#21262d";
          ledC.style.boxShadow = isC ? "0 0 8px #ff4444" : "none";

          ledR.style.backgroundColor = isR ? "#ff4444" : "#21262d";
          ledR.style.boxShadow = isR ? "0 0 8px #ff4444" : "none";
        }

        // 3. 동작(Action) 파싱 (마지막 파트 추출)
        const parts = e.data.split("|");
        if (parts.length > 2) {
          const actionText = parts[parts.length - 1].trim();
          actText.textContent = actionText;

          // 이미지 회전 및 불투명도 조절
          const carImg = document.getElementById("car-img");
          if (carImg) {
            let angle = 0;
            let translateY = 0;
            let opacity = 1.0;
            if (actionText === "직진") {
              angle = 0;
            } else if (actionText === "후진") {
              angle = 0;
              translateY = 15; // 후진 시 뒤로 밀리는 효과
            } else if (actionText === "좌회전") {
              angle = -35;
            } else if (actionText === "좌회전 더") {
              angle = -70;
            } else if (actionText === "우회전") {
              angle = 35;
            } else if (actionText === "우회전 더") {
              angle = 70;
            } else if (actionText === "정지" || actionText === "WAITING") {
              angle = 0;
              opacity = 0.5;
            }
            carImg.style.transform = `rotate(${angle}deg) translateY(${translateY}px)`;
            carImg.style.opacity = opacity;
          }
        }
      };
    }

    function updateButtonStates() {
      btnAutoScroll.style.opacity = autoScroll ? "1.0" : "0.4";
      btnAutoScroll.style.backgroundColor = autoScroll ? "#30363d" : "#21262d";
      btnAutoScroll.style.borderColor = autoScroll ? "#58a6ff" : "#30363d";
      
      btnTimestamp.style.opacity = showTimestamp ? "1.0" : "0.4";
      btnTimestamp.style.backgroundColor = showTimestamp ? "#30363d" : "#21262d";
      btnTimestamp.style.borderColor = showTimestamp ? "#58a6ff" : "#30363d";

      btnFilterMode.style.opacity = onlyShowFiltered ? "1.0" : "0.4";
      btnFilterMode.style.backgroundColor = onlyShowFiltered ? "#30363d" : "#21262d";
      btnFilterMode.style.borderColor = onlyShowFiltered ? "#58a6ff" : "#30363d";
    }

    function renderLogs() {
      term.innerHTML = "";
      
      // Process logs: keep or strip timestamp
      let processed = allLogs.map(line => {
        if (showTimestamp) {
          return line;
        } else {
          if (line.startsWith("[") && line.indexOf("]") === 12) {
            return line.substring(14);
          }
          return line;
        }
      });

      processed.forEach(line => {
        const matches = activeFilter ? line.includes(activeFilter) : true;
        const div = document.createElement("div");
        div.textContent = line;

        if (activeFilter) {
          if (onlyShowFiltered) {
            if (matches) {
              term.appendChild(div);
            }
          } else {
            if (!matches) {
              div.style.opacity = "0.25";
              div.style.color = "#8b949e";
            }
            term.appendChild(div);
          }
        } else {
          term.appendChild(div);
        }
      });

      if (autoScroll) {
        term.scrollTop = term.scrollHeight;
      }
    }

    function appendSingleLog(line) {
      let displayContent = line;
      if (!showTimestamp) {
        if (line.startsWith("[") && line.indexOf("]") === 12) {
          displayContent = line.substring(14);
        }
      }

      const matches = activeFilter ? displayContent.includes(activeFilter) : true;

      const div = document.createElement("div");
      div.textContent = displayContent;

      if (activeFilter) {
        if (onlyShowFiltered) {
          if (matches) {
            term.appendChild(div);
          }
        } else {
          if (!matches) {
            div.style.opacity = "0.25";
            div.style.color = "#8b949e";
          }
          term.appendChild(div);
        }
      } else {
        term.appendChild(div);
      }

      if (autoScroll) {
        term.scrollTop = term.scrollHeight;
      }
    }

    const presetButtons = document.querySelectorAll(".btn-preset");
    presetButtons.forEach(btn => {
      btn.addEventListener("click", () => {
        const wasActive = btn.classList.contains("active");
        
        // Deactivate all preset buttons
        presetButtons.forEach(b => {
          b.classList.remove("active");
          b.style.backgroundColor = "#21262d";
          b.style.borderColor = "#30363d";
          b.style.opacity = "0.4";
        });
        
        if (wasActive) {
          // Toggle off -> reset filter
          activeFilter = "";
        } else {
          // Toggle on
          btn.classList.add("active");
          btn.style.backgroundColor = "#30363d";
          btn.style.borderColor = "#58a6ff";
          btn.style.opacity = "1.0";
          activeFilter = btn.getAttribute("data-filter");
        }

        // If no filter is active, highlight the "A" (Show All) button
        if (activeFilter === "") {
          const aBtn = document.querySelector('.btn-preset[data-filter=""]');
          if (aBtn) {
            aBtn.classList.add("active");
            aBtn.style.backgroundColor = "#30363d";
            aBtn.style.borderColor = "#58a6ff";
            aBtn.style.opacity = "1.0";
          }
        }
        renderLogs();
      });
    });

    btnAutoScroll.addEventListener("click", () => {
      autoScroll = !autoScroll;
      updateButtonStates();
      if (autoScroll) {
        term.scrollTop = term.scrollHeight;
      }
    });

    btnTimestamp.addEventListener("click", () => {
      showTimestamp = !showTimestamp;
      updateButtonStates();
      renderLogs();
    });

    btnFilterMode.addEventListener("click", () => {
      onlyShowFiltered = !onlyShowFiltered;
      updateButtonStates();
      renderLogs();
    });

    btnClear.addEventListener("click", () => {
      allLogs = [];
      renderLogs();
    });

    updateButtonStates();

    function getTimestamp() {
      const now = new Date();
      const h = now.getHours().toString().padStart(2, '0');
      const m = now.getMinutes().toString().padStart(2, '0');
      const s = now.getSeconds().toString().padStart(2, '0');
      const ms = Math.floor(now.getMilliseconds() / 10).toString().padStart(2, '0');
      return `[${h}:${m}:${s}.${ms}]`;
    }

    connectEventSource();
  </script>
</body>
</html>
)rawhtml";

#endif

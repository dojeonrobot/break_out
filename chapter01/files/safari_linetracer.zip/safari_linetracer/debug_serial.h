// =========================================================
// Safari Linetracer - debug_serial.h v0.1.0
// =========================================================
#ifndef DEBUG_SERIAL_H
#define DEBUG_SERIAL_H

#include <Arduino.h>
#include <WiFi.h>

// 타 헤더 파일에서 실제 정의될 클라이언트 객체들을 외부 참조(extern) 선언
extern WiFiClient sseClients[4];
extern WiFiClient telnetClient;

// 하드웨어 시리얼 참조 (원래의 Serial 객체 백업)
HardwareSerial& hwSerial = Serial;

class WebSerialClass : public Print {
public:
  size_t write(uint8_t c) override {
    size_t len = hwSerial.write(c);
    bufferLine(c);
    return len;
  }
  
  size_t write(const uint8_t *buffer, size_t size) override {
    size_t len = hwSerial.write(buffer, size);
    for (size_t i = 0; i < size; i++) {
      bufferLine(buffer[i]);
    }
    return len;
  }

  void begin(unsigned long baud) {
    hwSerial.begin(baud);
  }

private:
  String lineBuffer = "";
  void bufferLine(uint8_t c) {
    if (c == '\n') {
      // 1. Web SSE Client로 전송 (최대 4명 브로드캐스트)
      String dataToSend = "data: " + lineBuffer + "\n\n";
      for (int i = 0; i < 4; i++) {
        if (sseClients[i]) {
          if (sseClients[i].connected()) {
            sseClients[i].print(dataToSend);
            sseClients[i].flush();
          } else {
            sseClients[i].stop(); // 연결 끊어진 클라이언트 자원 즉시 반환
          }
        }
      }
      // 2. Telnet Client로 전송 (nc 용)
      if (telnetClient) {
        if (telnetClient.connected()) {
          telnetClient.println(lineBuffer);
          telnetClient.flush();
        } else {
          telnetClient.stop(); // 연결 끊어진 텔넷 클라이언트 자원 즉시 반환
        }
      }
      lineBuffer = "";
    } else if (c != '\r') {
      lineBuffer += (char)c;
    }
  }
};

WebSerialClass DebugSerial;
#define Serial DebugSerial

#endif
